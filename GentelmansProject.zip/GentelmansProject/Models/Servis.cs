﻿namespace GentelmansProject.Models
{
    public class Servis
    {
        public int Id { get; set; }
        public string Name { get; set; } = String.Empty;
        public int HizmetSuresi { get; set; }
        public int HizmetFiyat { get; set; }
    }
}
