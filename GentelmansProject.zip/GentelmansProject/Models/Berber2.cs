﻿namespace GentelmansProject.Models
{
    public class Berber2
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string UzmanlikAlani { get; set; } = string.Empty;
    }
}
