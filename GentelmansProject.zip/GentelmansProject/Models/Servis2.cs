﻿using System.ComponentModel.DataAnnotations;

namespace GentelmansProject.Models
{
    public class Servis2
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int HizmetSuresi { get; set; }
        public decimal HizmetFiyat { get; set; }
    }
}
