﻿namespace GentelmansProject.Models
{
    public class BerberViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string UzmanlikAlani { get; set; }
        public bool Musaitlik { get; set; }
    }
}
